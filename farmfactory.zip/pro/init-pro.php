<?php
/**
 * Init Pro
 * 
 * @package Farm Factory
 */

/**
 * Enavto API
 */
require FARMFACTORY_PATH . 'pro/envato-api.php';

/**
 * Pro Functions
 */
require FARMFACTORY_PATH . 'pro/functions-pro.php';

/**
 * Pro Functions
 */
require FARMFACTORY_PATH . 'pro/admin-page-pro.php';
