<?php
/**
 * Admin Page Pro
 * 
 * @package Envato API Functions
 */

/**
 * Admin Page License
 */
require FARMFACTORY_PATH . 'pro/admin-page-license.php';
