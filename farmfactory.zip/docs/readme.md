to perform frontend-backend communication we use this variables which loads to frontend. 

# Put 
Admin puts all vars mannually in admin panel. 

# Get

``window.factoryAddress`` - address of contract factory (need to deploy farm contract, can't be changed)

`window.farmAddress`  - address of contract admin deployed to farm (main contract)

`window.rewardsAddress` - ERC20 address of reward token (loaded from window.farmAddress)

`window.stakingAddress` - ERC20 address of reward token (loaded from window.farmAddress) 
