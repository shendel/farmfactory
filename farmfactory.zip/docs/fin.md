## payouts
| date   | balance | status |
|--------|-----------------|------------|
| 15.10.2021 |  2827   | on noxon's bannk |
| 15.11.2021 |  2087 (+ 2827 не потратили) =  $4 914  | on noxon's bannk |
| 15.12.2021 |  2974 (+ 350к руб) =  $2974 + 350к налом  |  |
| 07.01.2022 |  0  | lotte | 
| 15.01.2022 |  1649  | bank |
| 15.02.2022 |  5514 (+1649) = 7163 $ (11.04 -5k) | alfabank |
| 15.06.2022 |  7132 (+2163) = 9295 $ | payoneer |
| 15.07.2022 |  9295 (+2000 - 450) = 10845 $ | payoneer |
| 15.08.2022 |  10845 (+2700 - 450 - 2179) = 8216 $ | payoneer |
| 15.09.2022 |  8216 (+1570 - 220 - 2050 - 2550) = 4966 $ | payoneer |
| 15.12.2022 |  4966 (-600 - 4366 ) | 0 |

инструкция: смотрим когда была последняя payouts, добавляем income+other income который был с тех пор (кастом джоб не считаем, там индивидуально), добавляем в "minus" расходку. далее смотрим когда был последний payout, и считаем прибыль с той даты, добавляем новую строку в payouts и в статусе пишем у когдо бабки. СЛЕДИТЕ за датами! 

## income:
  
| date   | amount | 
|--------|-----------------------------|
| 26 jan | -257 $ in 0.188252076 ETH (deploy to mainnet)     | 
| 4 feb | 100 $ (add bsc)  | 
| 15 feb | 94 $ (envato 01.2021 earnings)  | 
| 14 mar | 200 $ (Ticket #T000065 from Sam Language: en)  | 
| 15 mar | 743 $ (envato 02.2021 earnings)  | 
| 2 apr mar | -880 $ gorinich party  | 
| 15 jun | 2004 $ (envato 02.2021-05.2021 earnings)  | 
| 15 jul | 1000 $ (1500 (envato 06.2021 earnings) -  $500 freelancers) | 
| 15 oct | 2350 $ (2500 (envato 07,08,09.2021 earnings) - 150 freelancers) | 
| 15 nov | 2087 $ (2147.94 $ envato 10.2021 earnings - 60 freelancers) | 
| 15 dec 21 | 2974 $ (3034 $ envato 11.2021 earnings - 60 freelancers) | 
| 15 01 22 | 1649 $ (1769 $ envato - 120 freelancers ) |
| 15 02 22 | 5514 $ (4194 $ envato + 1500 other - 180 freelancers ) |
| 15 03 22 | 1878 $ (2898 $ env feb - 1020) |
| 15 04 22 | 1614 $ (2784 $ env march - 1170) |
| 15 05 22 | 2890 $ (2890 $ env apr ) |
| 15 06 22 | 750 $ (1350 $ env may - 600) |
| 15 07 22 | 2000 $ (2000 $ env jun) |
| 15 08 22 | 2700 $ (2700 $ env jul) |
| 15 09 22 | 750 $ (1570 $ env aug) |
| 15 10 22 | 0 $ (0 $ env sep) |
| 15 11 22 | 0 $ (0 $ env oct) |

### other income (only sales, not custom job etc)..
| date   | amount | 
|--------|-----------------------------|
| 21 mar | 300 $ (#T000071) |
| 13 apr | 299 $ (#T000084) |
| ------ | ---- |
| 20 jun | 400 $ (@rekl...) |
| 29 jun | 499 $ (@bitcoinau...) |
| 31 aug | 477 $ (etheum by) |
| 29 oct 21 | 490 $ #T000201  |
| 17.01 | 1500 $ #T000248 |

## minus
| date   | amount | 
|--------|-----------------------------|
| 28.07.21 |  - $330 (ion)   |
| 28.07.21 |  - $160 (dis)   |
| 08.09.21 |  - $160 (dis)   |
| 15.10.21 |  - $60 (shendel tokenprice shortcode)   |
| 15.12.21 |  - $60 (vit walletconnect fix)   |
| 15.01.22 |  - $120 (vit support & fixes)   |
| 15.02.22 |  - $180 (vit support & fixes)   |
| 15.03.22 |  - $1020 (vit support & fixes)   |
| 19.04.22 |  - $1170 (vit support & fixes)   |
| 22.06.22 |  - $600 (vit support & fixes)   |
| 10.08.22 |  - $2176 (koln etc..)   |
| 23.08.22 |  - $450 (vit support & fixes)   |
| 26.08.22 |  - $120 (tax)   |
| 26.08.22 |  - $2050 (to usdt)   |
| 15.09.22 |  - $100 (tax)   |
| 15.09.22 |  - $2550 (sber)   |
| 06.12.22 |  - $600 (vit support & fixes)   |
| 06.12.22 |  - $4366 (cashout)   |
